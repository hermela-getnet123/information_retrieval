import fitz
import re
import math
import tkinter as tk 
from tkinter import messagebox, scrolledtext
from nltk.corpus import stopwords
import os
from nltk.stem import PorterStemmer
from collections import Counter, defaultdict
import matplotlib.pyplot as plt
pdf_dir= "C:\Users\hp\Desktop\corpus"
pdf_paths = [os.path.join(pdf_dir,fname) for fname in os.listdir(pdf_dir) if fname.endswith(".pdf")]
all_documents = []
for file_path in pdf_paths:
    doc = fitz.open(file_path)
    text = ""
    for page in doc:
        text += page.get_text()
    doc.close()
    cleaned_content = re.sub(r'<[^>]+>', '', text)
    
    with open('cleaned_file.pdf', 'w', encoding='utf-8') as file:
        file.write(cleaned_content)
        print("Markup has been removed and saved to 'cleaned_file.txt'.")
    #Lowercase the cleaned content
    lowered_content = cleaned_content.lower()
    
    #Tokenize the text
    tokens = re.findall(r'\b\w+\b', lowered_content)
    #print(tokens)

    #Define output paths (to your Desktop)
    desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")
    file_inline = os.path.join(desktop_path, "tokenized_words_inline.txt")


    with open(file_inline, "w", encoding="utf-8") as f1:
        f1.write(" ".join(tokens)) 

    print("Tokenized words saved to Desktop:")

    stopwords_custom = set([
    "i", "me", "my", "myself", "we", "our", "ours", "ourselves", "you", "your", "yours", "yourself", "yourselves", 
    "he", "him", "his", "himself", "she", "her", "hers", "herself", "it", "its", "itself", "they", "them", "their", 
    "theirs", "themselves", "what", "which", "who", "whom", "this", "that", "these", "those", "am", "is", "are", "was", 
    "were", "be", "been", "being", "have", "has", "had", "having", "do", "does", "did", "doing", "a", "an", "the", "and", 
    "but", "if", "or", "because", "as", "until", "while", "of", "at", "by", "for", "with", "about", "against", "between", 
    "into", "through", "during", "before", "after", "above", "below", "to", "from", "up", "down", "in", "out", "on", "off", 
    "over", "under", "again", "further", "then", "once", "here", "there", "when", "where", "why", "how", "all", "any", 
    "both", "each", "few", "more", "most", "other", "some", "such", "no", "nor", "not", "only", "own", "same", "so", 
    "than", "too", "very", "s", "t", "can", "will", "just", "don", "should", "now", "d", "ll", "m", "o", "re", "ve", 
    "y", "ain", "aren", "couldn", "didn", "doesn", "hadn", "hasn", "haven", "isn", "ma", "mightn", "mustn", "needn", 
    "shan", "shouldn", "wasn", "weren", "won", "wouldn"
    ])

    tf_list = []
    df = defaultdict(int)

    filtered_words = [word for word in tokens if word.isalnum() and word.lower() not in stopwords_custom]

    file_filtered = os.path.join(desktop_path, "filtered_words.txt")
    with open(file_filtered, "w", encoding="utf-8") as f2:
        f2.write(" ".join(filtered_words)) 
    print(f"Filtered words saved to: {file_filtered}")
    
    print("""
    """)
  # Stemming words
    stemmer = PorterStemmer()
    stemmed_words = [stemmer.stem(word) for word in filtered_words]
    all_documents.append(stemmed_words)
  
    file_stemmed = os.path.join(desktop_path, "stemmed_words.txt")
    with open(file_stemmed, "w", encoding="utf-8") as f3:
        f3.write(" ".join(stemmed_words)) 
    print(f"Stemmed words saved to: {file_stemmed}")
    
for doc_index, stemmed_doc in enumerate(all_documents, 1):
    print(f"\n--- Document {doc_index} ---")

    # Term Frequency
    term_count = Counter(stemmed_doc)
    total_terms = len(stemmed_doc)
    tf = {term: count / total_terms for term, count in term_count.items()}
    
    # Sort by TF
    sorted_tf = sorted(tf.items(), key=lambda x: x[1], reverse=True)
    print("\n--- Term Frequency (TF) ---")
    for term, freq in sorted_tf:
        print(f"{term:15} : {freq:.6f}")

     #Document fequency
    df = defaultdict(int)

    for doc in all_documents:
        unique_terms = set(doc)
        for term in unique_terms:
            df[term] += 1

    print("\n--- Document Frequency (DF) ---")
    for term, doc_count in df.items():
        print(f"{term:15} : {doc_count}")

    print("\n--- Zipf's Law Check: frequency × rank ---")
    for rank, (term, freq) in enumerate(sorted_tf, 1):
        product = rank * freq
        print(f"{rank}. {term:15} | TF: {freq:.6f} | Rank x Freq: {product:.6f}")

    # Plotting
    ranks = list(range(1, len(sorted_tf) + 1))
    frequencies = [freq for _, freq in sorted_tf]

    plt.figure(figsize=(8, 5))
    plt.plot(ranks, frequencies, marker='o', linestyle='-', color='blue')
    plt.xscale('log')
    plt.yscale('log')
    plt.xlabel("Rank (log scale)")
    plt.ylabel("Term Frequency (log scale)")
    plt.title(f"Word Frequency vs Rank (Document {doc_index})")
    plt.grid(True)
    plt.tight_layout()
    plt.show()

# TF-IDF
N = len(all_documents)
idf = {}
tfidf_docs = []
inverted_index = defaultdict(list)

df = defaultdict(int)
for doc in all_documents:
    unique_terms = set(doc)
    for term in unique_terms:
        df[term] += 1

for doc_id, doc in enumerate(all_documents):
    term_counts = Counter(doc)
    total_terms = len(doc)
    tfidf = {}
    
    for term, count in term_counts.items():
        tf = count / total_terms
        idf_term = math.log(N / df[term])
        idf[term] = idf_term
        tfidf_score = tf * idf_term
        tfidf[term] = tfidf_score
        inverted_index[term].append((doc_id, tfidf_score))

    tfidf_docs.append(tfidf)

# The Engine
def preprocess_query(query):
    lowered = query.lower()
    tokens = re.findall(r'\b\w+\b', lowered)
    filtered = [word for word in tokens if word not in stopwords_custom]
    stemmed = [PorterStemmer().stem(word) for word in filtered]
    return stemmed

def search_documents(query, top_k=5):
    query_terms = preprocess_query(query)
    tf_query = Counter(query_terms)
    total_q_terms = len(query_terms)

    query_vec = {}
    for term in tf_query:
        if term in idf:
            query_vec[term] = (tf_query[term] / total_q_terms) * idf[term]

    query_norm = math.sqrt(sum(v ** 2 for v in query_vec.values()))
    doc_scores = defaultdict(float)

    for term, q_val in query_vec.items():
        for doc_id, d_val in inverted_index.get(term, []):
            doc_scores[doc_id] += q_val * d_val

    for doc_id in doc_scores:
        doc_vec = tfidf_docs[doc_id]
        doc_norm = math.sqrt(sum(v ** 2 for v in doc_vec.values()))
        if doc_norm != 0:
            doc_scores[doc_id] /= (query_norm * doc_norm)

    ranked = sorted(doc_scores.items(), key=lambda x: x[1], reverse=True)
    return ranked[:top_k]

# GUI 
doc_names = [os.path.basename(path) for path in pdf_paths]

def start_gui():
    def on_search():
        query = entry.get()
        results = search_documents(query)
        result_box.delete("1.0", tk.END)
        if not results:
            result_box.insert(tk.END, "No matching documents found.")
        else:
            for doc_id, score in results:
                result_box.insert(tk.END, f"{doc_names[doc_id]} - Score: {score:.4f}\n")

    root = tk.Tk()
    root.title("PDF Search Engine")

    tk.Label(root, text="Search Query:").pack(pady=5)
    entry = tk.Entry(root, width=60)
    entry.pack(pady=5)

    tk.Button(root, text="Search", command=on_search).pack(pady=5)

    result_box = scrolledtext.ScrolledText(root, width=80, height=20)
    result_box.pack(padx=10, pady=10)

    root.mainloop()

start_gui()

    

    

